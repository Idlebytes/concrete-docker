$(function() {
    $('.ccm-block-feature-item-hover-wrapper').tooltip();
})
